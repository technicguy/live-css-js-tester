// Enhanced Content Script for Live CSS & JS Tester Extension
(function() {
  'use strict';
  
  // Prevent duplicate loading and conflicts
  if (window.liveCssJsTesterLoaded) {
    console.warn('Live CSS Tester: Content script already loaded, skipping...');
    return;
  }
  window.liveCssJsTesterLoaded = true;
  
  // Configuration constants
  const CONFIG = {
    styleId: 'live-css-tester-style',
    scriptClass: 'live-js-tester-script',
    retryAttempts: 3,
    retryDelay: 500,
    autoApplyDelay: 1000
  };

  // State management
  const state = {
    cssInjected: false,
    jsExecuted: false,
    isReady: false,
    observer: null
  };

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeContentScript);
  } else {
    initializeContentScript();
  }

  // Main initialization function
  function initializeContentScript() {
    try {
      setupMutationObserver();
      handlePageLoad();
      state.isReady = true;
      console.log('Live CSS Tester: Content script initialized successfully');
    } catch (error) {
      console.error('Live CSS Tester: Initialization error:', error);
    }
  }

  // Setup mutation observer for dynamic content
  function setupMutationObserver() {
    if (!document.head) return;
    
    state.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        // Check if our injected styles were removed
        if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
          mutation.removedNodes.forEach((node) => {
            if (node.id === CONFIG.styleId) {
              state.cssInjected = false;
              console.log('Live CSS Tester: Injected CSS was removed');
            }
          });
        }
      });
    });
    
    state.observer.observe(document.head, {
      childList: true,
      subtree: true
    });
  }

  // Handle initial page load auto-apply
  async function handlePageLoad() {
    try {
      await waitForStorage();
      const settings = await getPageSettings();
      
      if (settings) {
        // Small delay to ensure page is fully loaded
        setTimeout(() => {
          applyPinnedCode(settings);
        }, CONFIG.autoApplyDelay);
      }
    } catch (error) {
      console.error('Live CSS Tester: Error handling page load:', error);
    }
  }

  // Wait for Chrome storage to be available
  function waitForStorage(maxWait = 5000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      
      function checkStorage() {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          resolve();
        } else if (Date.now() - startTime > maxWait) {
          reject(new Error('Chrome storage not available'));
        } else {
          setTimeout(checkStorage, 100);
        }
      }
      
      checkStorage();
    });
  }

  // Get settings for current page
  async function getPageSettings() {
    try {
      const hostname = window.location.hostname;
      const key = `settings_${hostname}`;
      
      return new Promise((resolve) => {
        chrome.storage.local.get(key, (result) => {
          if (chrome.runtime.lastError) {
            console.warn('Live CSS Tester: Storage error:', chrome.runtime.lastError);
            resolve(null);
          } else {
            resolve(result[key] || null);
          }
        });
      });
    } catch (error) {
      console.error('Live CSS Tester: Error getting page settings:', error);
      return null;
    }
  }

  // Apply pinned code automatically
  async function applyPinnedCode(settings) {
    try {
      // Auto-apply pinned CSS
      if (settings.css?.pinned && settings.css?.code && settings.css?.enabled !== false) {
        await injectCSS(settings.css.code);
        console.log('Live CSS Tester: Auto-applied pinned CSS');
      }
      
      // Auto-apply pinned JavaScript
      if (settings.js?.pinned && settings.js?.code && settings.js?.enabled !== false) {
        await executeJavaScript(settings.js.code);
        console.log('Live CSS Tester: Auto-applied pinned JavaScript');
      }
    } catch (error) {
      console.error('Live CSS Tester: Error auto-applying pinned code:', error);
    }
  }

  // Enhanced CSS injection with error handling and retries
  async function injectCSS(css, retryCount = 0) {
    try {
      if (!css || typeof css !== 'string') {
        throw new Error('Invalid CSS provided');
      }

      // Remove existing injected CSS
      removeExistingCSS();
      
      // Ensure head exists
      await ensureHeadExists();
      
      // Create and inject new CSS
      const style = document.createElement('style');
      style.id = CONFIG.styleId;
      style.type = 'text/css';
      style.textContent = css;
      
      // Add metadata for tracking
      style.setAttribute('data-injected-by', 'live-css-tester');
      style.setAttribute('data-injected-at', Date.now().toString());
      
      document.head.appendChild(style);
      state.cssInjected = true;
      
      // Verify injection was successful
      if (!document.getElementById(CONFIG.styleId)) {
        throw new Error('CSS injection verification failed');
      }
      
      return { success: true, message: 'CSS injected successfully' };
    } catch (error) {
      console.error('Live CSS Tester: CSS injection error:', error);
      
      // Retry logic
      if (retryCount < CONFIG.retryAttempts) {
        console.log(`Live CSS Tester: Retrying CSS injection (${retryCount + 1}/${CONFIG.retryAttempts})`);
        await new Promise(resolve => setTimeout(resolve, CONFIG.retryDelay));
        return injectCSS(css, retryCount + 1);
      }
      
      throw error;
    }
  }

  // Remove existing CSS injection
  function removeExistingCSS() {
    const existingStyles = document.querySelectorAll(`#${CONFIG.styleId}, style[data-injected-by="live-css-tester"]`);
    existingStyles.forEach(style => {
      try {
        style.remove();
      } catch (error) {
        console.warn('Live CSS Tester: Error removing existing style:', error);
      }
    });
    state.cssInjected = false;
  }

  // Ensure document.head exists
  async function ensureHeadExists(maxWait = 3000) {
    if (document.head) return;
    
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      
      function checkHead() {
        if (document.head) {
          resolve();
        } else if (Date.now() - startTime > maxWait) {
          // Create head if it doesn't exist
          const head = document.createElement('head');
          document.documentElement.insertBefore(head, document.body);
          resolve();
        } else {
          setTimeout(checkHead, 50);
        }
      }
      
      checkHead();
    });
  }

  // Enhanced JavaScript execution with console capture and error handling
  async function executeJavaScript(js, retryCount = 0) {
    try {
      if (!js || typeof js !== 'string') {
        throw new Error('Invalid JavaScript provided');
      }

      // Clean up previous executions
      cleanupPreviousScripts();
      
      // Create execution environment with console capture
      const logs = [];
      const originalConsole = captureConsoleOutput(logs);
      
      try {
        // Create script element for proper execution context
        const script = document.createElement('script');
        script.className = CONFIG.scriptClass;
        script.setAttribute('data-injected-by', 'live-css-tester');
        script.setAttribute('data-injected-at', Date.now().toString());
        
        // Wrap the user code in error handling
        script.textContent = `
          (function() {
            try {
              ${js}
            } catch (error) {
              console.error('Live CSS Tester JS Error:', error.message);
              console.error('Stack:', error.stack);
            }
          })();
        `;
        
        // Execute the script
        const target = document.head || document.body || document.documentElement;
        if (target) {
          target.appendChild(script);
          state.jsExecuted = true;
          
          // Clean up script element after short delay
          setTimeout(() => {
            if (script.parentNode) {
              script.parentNode.removeChild(script);
            }
          }, 100);
        } else {
          throw new Error('No suitable parent element for script execution');
        }
        
      } finally {
        // Restore original console
        restoreConsoleOutput(originalConsole);
      }
      
      return { 
        success: true, 
        message: 'JavaScript executed successfully',
        logs: logs 
      };
      
    } catch (error) {
      console.error('Live CSS Tester: JavaScript execution error:', error);
      
      // Retry logic
      if (retryCount < CONFIG.retryAttempts) {
        console.log(`Live CSS Tester: Retrying JavaScript execution (${retryCount + 1}/${CONFIG.retryAttempts})`);
        await new Promise(resolve => setTimeout(resolve, CONFIG.retryDelay));
        return executeJavaScript(js, retryCount + 1);
      }
      
      throw error;
    }
  }

  // Clean up previously executed scripts
  function cleanupPreviousScripts() {
    const existingScripts = document.querySelectorAll(`script[data-injected-by="live-css-tester"]`);
    existingScripts.forEach(script => {
      try {
        if (script.parentNode) {
          script.parentNode.removeChild(script);
        }
      } catch (error) {
        console.warn('Live CSS Tester: Error cleaning up script:', error);
      }
    });
  }

  // Capture console output during script execution
  function captureConsoleOutput(logs) {
    const originalConsole = {
      log: console.log,
      error: console.error,
      warn: console.warn,
      info: console.info
    };
    
    console.log = (...args) => {
      logs.push({ type: 'log', message: args.join(' '), timestamp: Date.now() });
      originalConsole.log.apply(console, args);
    };
    
    console.error = (...args) => {
      logs.push({ type: 'error', message: args.join(' '), timestamp: Date.now() });
      originalConsole.error.apply(console, args);
    };
    
    console.warn = (...args) => {
      logs.push({ type: 'warn', message: args.join(' '), timestamp: Date.now() });
      originalConsole.warn.apply(console, args);
    };
    
    console.info = (...args) => {
      logs.push({ type: 'info', message: args.join(' '), timestamp: Date.now() });
      originalConsole.info.apply(console, args);
    };
    
    return originalConsole;
  }

  // Restore original console functions
  function restoreConsoleOutput(originalConsole) {
    Object.assign(console, originalConsole);
  }

  // Get current page information
  function getPageInfo() {
    return {
      url: window.location.href,
      hostname: window.location.hostname,
      pathname: window.location.pathname,
      title: document.title,
      readyState: document.readyState,
      cssInjected: state.cssInjected,
      jsExecuted: state.jsExecuted,
      timestamp: Date.now()
    };
  }

  // Enhanced message listener with comprehensive error handling
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // Async wrapper for message handling
    (async function() {
      try {
        if (!state.isReady) {
          throw new Error('Content script not ready');
        }

        switch (request.action) {
          case 'injectCSS':
            if (!request.css) {
              throw new Error('No CSS provided');
            }
            const cssResult = await injectCSS(request.css);
            sendResponse(cssResult);
            break;
            
          case 'removeCSS':
            removeExistingCSS();
            sendResponse({ success: true, message: 'CSS removed successfully' });
            break;
            
          case 'executeJS':
            if (!request.js) {
              throw new Error('No JavaScript provided');
            }
            const jsResult = await executeJavaScript(request.js);
            sendResponse(jsResult);
            break;
            
          case 'getPageInfo':
            sendResponse(getPageInfo());
            break;
            
          case 'checkStatus':
            sendResponse({
              ready: state.isReady,
              cssInjected: state.cssInjected,
              jsExecuted: state.jsExecuted
            });
            break;
            
          case 'cleanup':
            removeExistingCSS();
            cleanupPreviousScripts();
            sendResponse({ success: true, message: 'Cleanup completed' });
            break;
            
          default:
            throw new Error(`Unknown action: ${request.action}`);
        }
      } catch (error) {
        console.error('Live CSS Tester: Message handling error:', error);
        sendResponse({ 
          success: false, 
          error: error.message,
          timestamp: Date.now()
        });
      }
    })();
    
    // Keep message channel open for async responses
    return true;
  });

  // Handle page navigation
  window.addEventListener('beforeunload', function() {
    try {
      // Cleanup on page unload
      if (state.observer) {
        state.observer.disconnect();
      }
      
      // Optional: Remove injected styles and scripts
      // removeExistingCSS();
      // cleanupPreviousScripts();
      
    } catch (error) {
      console.warn('Live CSS Tester: Cleanup error:', error);
    }
  });

  // Handle page visibility changes
  document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
      // Page became visible, check if we need to reapply
      setTimeout(() => {
        if (state.cssInjected && !document.getElementById(CONFIG.styleId)) {
          console.log('Live CSS Tester: CSS missing, may need reapplication');
        }
      }, 100);
    }
  });

  // Export for debugging (development only)
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
    try {
      const manifest = chrome.runtime.getManifest();
      if (manifest.version && manifest.version.includes('dev')) {
        window.liveCssTesterDebug = {
          state,
          CONFIG,
          injectCSS,
          executeJavaScript,
          removeExistingCSS,
          cleanupPreviousScripts,
          getPageInfo
        };
      }
    } catch (error) {
      // Ignore errors in debug setup
    }
  }

  console.log('Live CSS Tester: Content script loaded and ready');

})();