// Enhanced Popup JavaScript for Live CSS & JS Tester
(function() {
    'use strict';

    // Configuration constants
    const CONFIG = {
        debounceDelay: 500,
        autocompleteMinChars: 2,
        maxConsoleLines: 50,
        storagePrefix: 'liveTester_',
        themes: ['light', 'dark', 'auto']
    };

    // State management
    const state = {
        isFloating: false,
        isMinimized: false,
        currentTab: 'css',
        settings: {
            theme: 'auto',
            fontSize: 13,
            autoApplyDelay: true,
            syntaxHighlight: true
        },
        isDragging: false,
        dragStart: { x: 0, y: 0 }
    };

    // CSS properties for autocomplete (cached from CSSOM)
    let cssProperties = [];
    let cssValues = new Map();

    // DOM elements cache
    const elements = {};

    // Initialize extension
    document.addEventListener('DOMContentLoaded', initializeExtension);

    async function initializeExtension() {
        try {
            cacheElements();
            await loadCSSProperties();
            await loadSettings();
            setupEventListeners();
            await loadCurrentTab();
            applyTheme();
            updateStatus('Extension loaded successfully');
        } catch (error) {
            console.error('Extension initialization error:', error);
            updateStatus('Extension initialization failed', 'error');
        }
    }

    // Cache DOM elements for performance
    function cacheElements() {
        const selectors = {
            // Main container
            container: '#mainContainer',
            dragHandle: '#dragHandle',
            
            // Window controls
            minimizeBtn: '#minimizeBtn',
            detachBtn: '#detachBtn',
            closeBtn: '#closeBtn',
            
            // Tab system
            tabButtons: '.tab-btn',
            tabContents: '.tab-content',
            
            // CSS elements
            cssEditor: '#cssEditor',
            cssEnabled: '#cssEnabled',
            cssPinned: '#cssPinned',
            applyCssBtn: '#applyCss',
            clearCssBtn: '#clearCss',
            beautifyCssBtn: '#beautifyCss',
            cssAutocomplete: '#cssAutocomplete',
            cssLineCount: '#cssLineCount',
            cssCharCount: '#cssCharCount',
            
            // JavaScript elements
            jsEditor: '#jsEditor',
            jsEnabled: '#jsEnabled',
            jsPinned: '#jsPinned',
            runJsBtn: '#runJs',
            clearJsBtn: '#clearJs',
            beautifyJsBtn: '#beautifyJs',
            jsAutocomplete: '#jsAutocomplete',
            jsLineCount: '#jsLineCount',
            jsCharCount: '#jsCharCount',
            
            // Console
            consoleContent: '#consoleContent',
            clearConsoleBtn: '#clearConsole',
            
            // Settings
            themeSelect: '#themeSelect',
            fontSizeSlider: '#fontSizeSlider',
            fontSizeValue: '#fontSizeValue',
            autoApplyDelay: '#autoApplyDelay',
            syntaxHighlight: '#syntaxHighlight',
            exportDataBtn: '#exportData',
            importDataBtn: '#importData',
            importFile: '#importFile',
            clearAllDataBtn: '#clearAllData',
            
            // Status
            statusText: '#statusText',
            lastUpdate: '#lastUpdate',
            currentUrl: '#currentUrl',
            connectionStatus: '#connectionStatus',
            
            // Others
            shortcutsHelp: '#shortcutsHelp'
        };

        Object.keys(selectors).forEach(key => {
            elements[key] = document.querySelector(selectors[key]);
            if (!elements[key] && !key.endsWith('s')) {
                console.warn(`Element not found: ${selectors[key]}`);
            }
        });

        // Handle multiple elements
        elements.tabButtons = document.querySelectorAll('.tab-btn');
        elements.tabContents = document.querySelectorAll('.tab-content');
    }

    // Load CSS properties from CSSOM for autocomplete
    async function loadCSSProperties() {
        try {
            // Get CSS properties from the browser's CSSOM
            const tempElement = document.createElement('div');
            document.body.appendChild(tempElement);
            
            const computedStyle = getComputedStyle(tempElement);
            cssProperties = Array.from(computedStyle).sort();
            
            // Common CSS values for properties
            cssValues.set('display', ['block', 'inline', 'inline-block', 'flex', 'grid', 'none']);
            cssValues.set('position', ['static', 'relative', 'absolute', 'fixed', 'sticky']);
            cssValues.set('overflow', ['visible', 'hidden', 'scroll', 'auto']);
            cssValues.set('text-align', ['left', 'right', 'center', 'justify']);
            cssValues.set('font-weight', ['normal', 'bold', '100', '200', '300', '400', '500', '600', '700', '800', '900']);
            cssValues.set('cursor', ['pointer', 'default', 'text', 'move', 'help', 'wait', 'crosshair']);
            
            document.body.removeChild(tempElement);
            console.log(`Loaded ${cssProperties.length} CSS properties`);
        } catch (error) {
            console.error('Error loading CSS properties:', error);
            // Fallback to basic properties
            cssProperties = ['color', 'background', 'font-size', 'padding', 'margin', 'border', 'display', 'position'];
        }
    }

    // Setup all event listeners
    function setupEventListeners() {
        // Window controls
        elements.minimizeBtn?.addEventListener('click', toggleMinimize);
        elements.detachBtn?.addEventListener('click', toggleFloat);
        elements.closeBtn?.addEventListener('click', closePopup);

        // Dragging functionality
        elements.dragHandle?.addEventListener('mousedown', startDragging);
        document.addEventListener('mousemove', handleDragging);
        document.addEventListener('mouseup', stopDragging);

        // Tab switching
        elements.tabButtons.forEach(button => {
            button.addEventListener('click', () => switchTab(button.dataset.tab));
        });

        // CSS controls
        elements.cssEnabled?.addEventListener('change', handleCssEnabledChange);
        elements.cssPinned?.addEventListener('change', handleCssPinnedChange);
        elements.applyCssBtn?.addEventListener('click', applyCss);
        elements.clearCssBtn?.addEventListener('click', clearCss);
        elements.beautifyCssBtn?.addEventListener('click', beautifyCss);

        // JavaScript controls
        elements.jsEnabled?.addEventListener('change', handleJsEnabledChange);
        elements.jsPinned?.addEventListener('change', handleJsPinnedChange);
        elements.runJsBtn?.addEventListener('click', runJavaScript);
        elements.clearJsBtn?.addEventListener('click', clearJavaScript);
        elements.beautifyJsBtn?.addEventListener('click', beautifyJavaScript);
        elements.clearConsoleBtn?.addEventListener('click', clearConsole);

        // Editor events
        setupEditorEvents();

        // Settings
        elements.themeSelect?.addEventListener('change', handleThemeChange);
        elements.fontSizeSlider?.addEventListener('input', handleFontSizeChange);
        elements.autoApplyDelay?.addEventListener('change', handleAutoApplyChange);
        elements.syntaxHighlight?.addEventListener('change', handleSyntaxHighlightChange);
        elements.exportDataBtn?.addEventListener('click', exportData);
        elements.importDataBtn?.addEventListener('click', () => elements.importFile?.click());
        elements.importFile?.addEventListener('change', importData);
        elements.clearAllDataBtn?.addEventListener('click', clearAllData);

        // Keyboard shortcuts
        document.addEventListener('keydown', handleKeyboardShortcuts);

        // Window events
        window.addEventListener('beforeunload', saveSettings);
        window.addEventListener('resize', handleWindowResize);
    }

    // Setup editor-specific events
    function setupEditorEvents() {
        const editors = [
            { element: elements.cssEditor, type: 'css', autocomplete: elements.cssAutocomplete, 
              lineCount: elements.cssLineCount, charCount: elements.cssCharCount },
            { element: elements.jsEditor, type: 'js', autocomplete: elements.jsAutocomplete,
              lineCount: elements.jsLineCount, charCount: elements.jsCharCount }
        ];

        editors.forEach(({ element, type, autocomplete, lineCount, charCount }) => {
            if (!element) return;

            // Input events with debouncing
            let inputTimeout;
            element.addEventListener('input', (e) => {
                updateEditorStats(element, lineCount, charCount);
                saveSettings();
                
                // Auto-apply if enabled
                if (type === 'css' && elements.cssEnabled?.checked) {
                    clearTimeout(inputTimeout);
                    inputTimeout = setTimeout(() => applyCss(), CONFIG.debounceDelay);
                }

                // Autocomplete
                if (type === 'css') {
                    handleCssAutocomplete(e, autocomplete);
                }
            });

            // Focus events
            element.addEventListener('focus', () => {
                element.parentElement.classList.add('focused');
            });

            element.addEventListener('blur', () => {
                element.parentElement.classList.remove('focused');
                hideAutocomplete(autocomplete);
            });

            // Key events for autocomplete
            element.addEventListener('keydown', (e) => {
                if (type === 'css') {
                    handleAutocompleteKeydown(e, autocomplete);
                }
            });

            // Initialize stats
            updateEditorStats(element, lineCount, charCount);
        });
    }

    // CSS Autocomplete functionality
    function handleCssAutocomplete(event, dropdown) {
        const editor = event.target;
        const cursorPos = editor.selectionStart;
        const text = editor.value;
        const beforeCursor = text.substring(0, cursorPos);
        
        // Check if we're typing a CSS property
        const propertyMatch = beforeCursor.match(/([a-z-]+):\s*([^;}]*)$/i);
        const valueMatch = beforeCursor.match(/([a-z-]+):\s*([^;}]*)$/i);
        
        if (propertyMatch) {
            const [, property, value] = propertyMatch;
            if (cssValues.has(property) && value.length >= 1) {
                showValueAutocomplete(dropdown, property, value, editor, cursorPos);
                return;
            }
        }
        
        // Check for property autocomplete
        const propMatch = beforeCursor.match(/\s*([a-z-]*)$/i);
        if (propMatch && propMatch[1].length >= CONFIG.autocompleteMinChars) {
            showPropertyAutocomplete(dropdown, propMatch[1], editor, cursorPos);
        } else {
            hideAutocomplete(dropdown);
        }
    }

    function showPropertyAutocomplete(dropdown, query, editor, cursorPos) {
        const matches = cssProperties.filter(prop => 
            prop.toLowerCase().startsWith(query.toLowerCase())
        ).slice(0, 10);

        if (matches.length === 0) {
            hideAutocomplete(dropdown);
            return;
        }

        showAutocompleteDropdown(dropdown, matches.map(prop => ({
            text: prop,
            insertText: prop + ': ',
            type: 'property'
        })), editor, cursorPos - query.length);
    }

    function showValueAutocomplete(dropdown, property, query, editor, cursorPos) {
        const values = cssValues.get(property);
        if (!values) {
            hideAutocomplete(dropdown);
            return;
        }

        const matches = values.filter(value =>
            value.toLowerCase().startsWith(query.toLowerCase())
        );

        if (matches.length === 0) {
            hideAutocomplete(dropdown);
            return;
        }

        showAutocompleteDropdown(dropdown, matches.map(value => ({
            text: value,
            insertText: value,
            type: 'value'
        })), editor, cursorPos - query.length);
    }

    function showAutocompleteDropdown(dropdown, items, editor, insertPos) {
        dropdown.innerHTML = '';
        dropdown.style.display = 'block';

        items.forEach((item, index) => {
            const div = document.createElement('div');
            div.className = 'autocomplete-item';
            if (index === 0) div.classList.add('selected');
            div.textContent = item.text;
            div.dataset.insertText = item.insertText;
            div.dataset.insertPos = insertPos;
            
            div.addEventListener('click', () => {
                insertAutocomplete(editor, item.insertText, insertPos);
                hideAutocomplete(dropdown);
            });
            
            dropdown.appendChild(div);
        });
    }

    function hideAutocomplete(dropdown) {
        if (dropdown) {
            dropdown.style.display = 'none';
        }
    }

    function handleAutocompleteKeydown(event, dropdown) {
        if (dropdown.style.display === 'none') return;

        const items = dropdown.querySelectorAll('.autocomplete-item');
        const selected = dropdown.querySelector('.autocomplete-item.selected');
        let selectedIndex = Array.from(items).indexOf(selected);

        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                selectedIndex = (selectedIndex + 1) % items.length;
                updateAutocompleteSelection(items, selectedIndex);
                break;
                
            case 'ArrowUp':
                event.preventDefault();
                selectedIndex = selectedIndex <= 0 ? items.length - 1 : selectedIndex - 1;
                updateAutocompleteSelection(items, selectedIndex);
                break;
                
            case 'Enter':
            case 'Tab':
                event.preventDefault();
                if (selected) {
                    insertAutocomplete(event.target, selected.dataset.insertText, parseInt(selected.dataset.insertPos));
                    hideAutocomplete(dropdown);
                }
                break;
                
            case 'Escape':
                hideAutocomplete(dropdown);
                break;
        }
    }

    function updateAutocompleteSelection(items, selectedIndex) {
        items.forEach((item, index) => {
            item.classList.toggle('selected', index === selectedIndex);
        });
    }

    function insertAutocomplete(editor, insertText, insertPos) {
        const currentPos = editor.selectionStart;
        const text = editor.value;
        const newText = text.substring(0, insertPos) + insertText + text.substring(currentPos);
        
        editor.value = newText;
        editor.selectionStart = editor.selectionEnd = insertPos + insertText.length;
        editor.focus();
        
        // Trigger input event to update stats and save
        editor.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Window controls
    function toggleMinimize() {
        state.isMinimized = !state.isMinimized;
        elements.container.classList.toggle('minimized', state.isMinimized);
        elements.minimizeBtn.textContent = state.isMinimized ? '+' : '−';
        updateStatus(state.isMinimized ? 'Minimized' : 'Restored');
    }

    function toggleFloat() {
        state.isFloating = !state.isFloating;
        elements.container.classList.toggle('floating', state.isFloating);
        elements.detachBtn.textContent = state.isFloating ? '⧈' : '⧉';
        elements.detachBtn.title = state.isFloating ? 'Dock' : 'Detach/Float';
        updateStatus(state.isFloating ? 'Detached' : 'Docked');
    }

    function closePopup() {
        if (state.isFloating) {
            toggleFloat();
        } else {
            window.close();
        }
    }

    // Dragging functionality
    function startDragging(e) {
        if (!state.isFloating) return;
        
        state.isDragging = true;
        state.dragStart = { x: e.clientX, y: e.clientY };
        elements.container.style.cursor = 'grabbing';
        elements.dragHandle.style.cursor = 'grabbing';
        e.preventDefault();
    }

    function handleDragging(e) {
        if (!state.isDragging || !state.isFloating) return;
        
        const deltaX = e.clientX - state.dragStart.x;
        const deltaY = e.clientY - state.dragStart.y;
        
        const rect = elements.container.getBoundingClientRect();
        const newLeft = rect.left + deltaX;
        const newTop = rect.top + deltaY;
        
        elements.container.style.left = `${Math.max(0, Math.min(newLeft, window.innerWidth - rect.width))}px`;
        elements.container.style.top = `${Math.max(0, Math.min(newTop, window.innerHeight - rect.height))}px`;
        
        state.dragStart = { x: e.clientX, y: e.clientY };
    }

    function stopDragging() {
        state.isDragging = false;
        elements.container.style.cursor = '';
        elements.dragHandle.style.cursor = 'move';
    }

    // Tab switching
    function switchTab(tabName) {
        if (state.currentTab === tabName) return;
        
        state.currentTab = tabName;
        
        // Update tab buttons
        elements.tabButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        
        // Update tab content
        elements.tabContents.forEach(content => {
            const isActive = content.id === tabName + '-tab';
            content.classList.toggle('active', isActive);
            if (isActive) {
                content.classList.add('fade-in');
                setTimeout(() => content.classList.remove('fade-in'), 300);
            }
        });
        
        updateStatus(`Switched to ${tabName.toUpperCase()} tab`);
        saveSettings();
    }

    // CSS functions
    async function applyCss() {
        const css = elements.cssEditor?.value.trim();
        if (!css) {
            updateStatus('No CSS to apply', 'warning');
            return;
        }

        try {
            await executeInActiveTab('injectCSS', [css]);
            elements.cssEditor.classList.add('success');
            setTimeout(() => elements.cssEditor.classList.remove('success'), 1000);
            updateStatus('CSS applied successfully');
            await saveSettings();
        } catch (error) {
            console.error('CSS application error:', error);
            elements.cssEditor.classList.add('error');
            setTimeout(() => elements.cssEditor.classList.remove('error'), 2000);
            updateStatus('CSS application failed', 'error');
        }
    }

    async function clearCss() {
        if (elements.cssEditor) {
            elements.cssEditor.value = '';
            updateEditorStats(elements.cssEditor, elements.cssLineCount, elements.cssCharCount);
        }
        
        try {
            await executeInActiveTab('removeCSSInjection');
            updateStatus('CSS cleared');
        } catch (error) {
            console.error('CSS clear error:', error);
        }
        
        await saveSettings();
    }

    function beautifyCss() {
        const css = elements.cssEditor?.value;
        if (!css) return;

        try {
            // Simple CSS beautification
            const beautified = css
                .replace(/\s*{\s*/g, ' {\n    ')
                .replace(/;\s*/g, ';\n    ')
                .replace(/\s*}\s*/g, '\n}\n\n')
                .replace(/,\s*/g, ',\n')
                .trim();
            
            elements.cssEditor.value = beautified;
            updateEditorStats(elements.cssEditor, elements.cssLineCount, elements.cssCharCount);
            updateStatus('CSS formatted');
            saveSettings();
        } catch (error) {
            updateStatus('CSS formatting failed', 'error');
        }
    }

    // JavaScript functions
    async function runJavaScript() {
        const js = elements.jsEditor?.value.trim();
        if (!js) {
            addConsoleMessage('No JavaScript code to execute', 'warn');
            return;
        }

        try {
            clearConsole();
            const results = await executeInActiveTab('executeJavaScript', [js]);
            
            elements.jsEditor.classList.add('success');
            setTimeout(() => elements.jsEditor.classList.remove('success'), 1000);
            
            if (results && results[0]?.result) {
                const result = results[0].result;
                if (result.error) {
                    addConsoleMessage(`Error: ${result.error}`, 'error');
                } else if (result.logs?.length > 0) {
                    result.logs.forEach(log => addConsoleMessage(log.message, log.type));
                } else {
                    addConsoleMessage('JavaScript executed successfully', 'log');
                }
            }
            
            updateStatus('JavaScript executed');
            await saveSettings();
        } catch (error) {
            console.error('JavaScript execution error:', error);
            elements.jsEditor.classList.add('error');
            setTimeout(() => elements.jsEditor.classList.remove('error'), 2000);
            addConsoleMessage(`Execution Error: ${error.message}`, 'error');
            updateStatus('JavaScript execution failed', 'error');
        }
    }

    async function clearJavaScript() {
        if (elements.jsEditor) {
            elements.jsEditor.value = '';
            updateEditorStats(elements.jsEditor, elements.jsLineCount, elements.jsCharCount);
        }
        clearConsole();
        updateStatus('JavaScript cleared');
        await saveSettings();
    }

    function beautifyJavaScript() {
        const js = elements.jsEditor?.value;
        if (!js) return;

        try {
            // Simple JavaScript beautification
            const beautified = js
                .replace(/\s*{\s*/g, ' {\n    ')
                .replace(/;\s*(?=\S)/g, ';\n')
                .replace(/\s*}\s*/g, '\n}\n\n')
                .replace(/,\s*(?=\S)/g, ',\n    ')
                .trim();
            
            elements.jsEditor.value = beautified;
            updateEditorStats(elements.jsEditor, elements.jsLineCount, elements.jsCharCount);
            updateStatus('JavaScript formatted');
            saveSettings();
        } catch (error) {
            updateStatus('JavaScript formatting failed', 'error');
        }
    }

    // Console functions
    function addConsoleMessage(message, type = 'log') {
        if (!elements.consoleContent) return;

        const messageElement = document.createElement('div');
        messageElement.className = `console-${type}`;
        messageElement.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        
        elements.consoleContent.appendChild(messageElement);
        
        // Limit console lines
        const messages = elements.consoleContent.children;
        while (messages.length > CONFIG.maxConsoleLines) {
            elements.consoleContent.removeChild(messages[0]);
        }
        
        elements.consoleContent.scrollTop = elements.consoleContent.scrollHeight;
    }

    function clearConsole() {
        if (elements.consoleContent) {
            elements.consoleContent.innerHTML = '';
        }
    }

    // Editor utilities
    function updateEditorStats(editor, lineCountEl, charCountEl) {
        if (!editor) return;
        
        const lines = editor.value.split('\n').length;
        const chars = editor.value.length;
        
        if (lineCountEl) lineCountEl.textContent = `Lines: ${lines}`;
        if (charCountEl) charCountEl.textContent = `Characters: ${chars}`;
    }

    // Settings functions
    async function loadSettings() {
        try {
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            if (!tab?.url) return;

            elements.currentUrl.textContent = new URL(tab.url).hostname;

            const hostname = new URL(tab.url).hostname;
            const key = `settings_${hostname}`;
            const result = await chrome.storage.local.get([key, 'globalSettings']);
            
            const settings = result[key];
            const globalSettings = result.globalSettings || {};
            
            // Load global settings
            Object.assign(state.settings, globalSettings);
            applyGlobalSettings();
            
            // Load page-specific settings
            if (settings) {
                loadCssSettings(settings.css);
                loadJsSettings(settings.js);
            }
            
            // Apply pinned code if needed
            await applyPinnedCode();
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    function loadCssSettings(cssSettings) {
        if (!cssSettings) return;
        
        if (elements.cssEditor) elements.cssEditor.value = cssSettings.code || '';
        if (elements.cssEnabled) elements.cssEnabled.checked = cssSettings.enabled !== false;
        if (elements.cssPinned) elements.cssPinned.checked = cssSettings.pinned || false;
        
        updateEditorStats(elements.cssEditor, elements.cssLineCount, elements.cssCharCount);
    }

    function loadJsSettings(jsSettings) {
        if (!jsSettings) return;
        
        if (elements.jsEditor) elements.jsEditor.value = jsSettings.code || '';
        if (elements.jsEnabled) elements.jsEnabled.checked = jsSettings.enabled !== false;
        if (elements.jsPinned) elements.jsPinned.checked = jsSettings.pinned || false;
        
        updateEditorStats(elements.jsEditor, elements.jsLineCount, elements.jsCharCount);
    }

    function applyGlobalSettings() {
        if (elements.themeSelect) elements.themeSelect.value = state.settings.theme;
        if (elements.fontSizeSlider) {
            elements.fontSizeSlider.value = state.settings.fontSize;
            elements.fontSizeValue.textContent = `${state.settings.fontSize}px`;
        }
        if (elements.autoApplyDelay) elements.autoApplyDelay.checked = state.settings.autoApplyDelay;
        if (elements.syntaxHighlight) elements.syntaxHighlight.checked = state.settings.syntaxHighlight;
        
        // Apply font size to editors
        const fontSize = `${state.settings.fontSize}px`;
        if (elements.cssEditor) elements.cssEditor.style.fontSize = fontSize;
        if (elements.jsEditor) elements.jsEditor.style.fontSize = fontSize;
    }

    async function saveSettings() {
        try {
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            if (!tab?.url) return;

            const hostname = new URL(tab.url).hostname;
            const key = `settings_${hostname}`;
            
            const settings = {
                css: {
                    code: elements.cssEditor?.value || '',
                    enabled: elements.cssEnabled?.checked !== false,
                    pinned: elements.cssPinned?.checked || false
                },
                js: {
                    code: elements.jsEditor?.value || '',
                    enabled: elements.jsEnabled?.checked !== false,
                    pinned: elements.jsPinned?.checked || false
                }
            };
            
            await chrome.storage.local.set({
                [key]: settings,
                globalSettings: state.settings,
                lastTab: state.currentTab
            });
        } catch (error) {
            console.error('Error saving settings:', error);
        }
    }

    async function loadCurrentTab() {
        try {
            const result = await chrome.storage.local.get('lastTab');
            if (result.lastTab) {
                switchTab(result.lastTab);
            }
        } catch (error) {
            console.error('Error loading current tab:', error);
        }
    }

    // Apply pinned code automatically
    async function applyPinnedCode() {
        if (elements.cssPinned?.checked && elements.cssEditor?.value.trim()) {
            await applyCss();
        }
        
        if (elements.jsPinned?.checked && elements.jsEditor?.value.trim()) {
            await runJavaScript();
        }
    }

    // Event handlers
    function handleCssEnabledChange() {
        updateStatus('CSS live mode ' + (elements.cssEnabled.checked ? 'enabled' : 'disabled'));
        saveSettings();
    }

    function handleCssPinnedChange() {
        updateStatus('CSS ' + (elements.cssPinned.checked ? 'pinned' : 'unpinned'));
        saveSettings();
    }

    function handleJsEnabledChange() {
        updateStatus('JavaScript live mode ' + (elements.jsEnabled.checked ? 'enabled' : 'disabled'));
        saveSettings();
    }

    function handleJsPinnedChange() {
        updateStatus('JavaScript ' + (elements.jsPinned.checked ? 'pinned' : 'unpinned'));
        saveSettings();
    }

    function handleThemeChange() {
        state.settings.theme = elements.themeSelect.value;
        applyTheme();
        saveSettings();
        updateStatus(`Theme changed to ${state.settings.theme}`);
    }

    function handleFontSizeChange() {
        state.settings.fontSize = parseInt(elements.fontSizeSlider.value);
        elements.fontSizeValue.textContent = `${state.settings.fontSize}px`;
        applyGlobalSettings();
        saveSettings();
    }

    function handleAutoApplyChange() {
        state.settings.autoApplyDelay = elements.autoApplyDelay.checked;
        CONFIG.debounceDelay = state.settings.autoApplyDelay ? 500 : 0;
        saveSettings();
        updateStatus('Auto-apply delay ' + (state.settings.autoApplyDelay ? 'enabled' : 'disabled'));
    }

    function handleSyntaxHighlightChange() {
        state.settings.syntaxHighlight = elements.syntaxHighlight.checked;
        saveSettings();
        updateStatus('Syntax highlighting ' + (state.settings.syntaxHighlight ? 'enabled' : 'disabled'));
    }

    // Theme management
    function applyTheme() {
        const theme = state.settings.theme;
        if (theme === 'auto') {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.body.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
        } else {
            document.body.setAttribute('data-theme', theme);
        }
    }

    // Data management
    async function exportData() {
        try {
            const allData = await chrome.storage.local.get(null);
            const exportData = {
                version: '1.0.0',
                timestamp: new Date().toISOString(),
                data: allData
            };
            
            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `live-css-js-tester-backup-${new Date().toISOString().slice(0, 10)}.json`;
            a.click();
            
            URL.revokeObjectURL(url);
            updateStatus('Data exported successfully');
        } catch (error) {
            console.error('Export error:', error);
            updateStatus('Export failed', 'error');
        }
    }

    async function importData(event) {
        const file = event.target.files[0];
        if (!file) return;

        try {
            const text = await file.text();
            const importData = JSON.parse(text);
            
            if (!importData.data) {
                throw new Error('Invalid backup file format');
            }
            
            await chrome.storage.local.set(importData.data);
            await loadSettings();
            updateStatus('Data imported successfully');
            
            // Reset file input
            elements.importFile.value = '';
        } catch (error) {
            console.error('Import error:', error);
            updateStatus('Import failed', 'error');
            elements.importFile.value = '';
        }
    }

    async function clearAllData() {
        if (!confirm('Are you sure you want to clear all extension data? This cannot be undone.')) {
            return;
        }

        try {
            await chrome.storage.local.clear();
            
            // Reset UI
            if (elements.cssEditor) elements.cssEditor.value = '';
            if (elements.jsEditor) elements.jsEditor.value = '';
            if (elements.cssEnabled) elements.cssEnabled.checked = true;
            if (elements.jsEnabled) elements.jsEnabled.checked = true;
            if (elements.cssPinned) elements.cssPinned.checked = false;
            if (elements.jsPinned) elements.jsPinned.checked = false;
            
            clearConsole();
            updateStatus('All data cleared');
        } catch (error) {
            console.error('Clear data error:', error);
            updateStatus('Failed to clear data', 'error');
        }
    }

    // Keyboard shortcuts
    function handleKeyboardShortcuts(event) {
        // Ctrl+Enter - Apply/Run code
        if (event.ctrlKey && event.key === 'Enter') {
            event.preventDefault();
            if (state.currentTab === 'css') {
                applyCss();
            } else if (state.currentTab === 'js') {
                runJavaScript();
            }
        }
        
        // Ctrl+Shift+F - Format code
        if (event.ctrlKey && event.shiftKey && event.key === 'F') {
            event.preventDefault();
            if (state.currentTab === 'css') {
                beautifyCss();
            } else if (state.currentTab === 'js') {
                beautifyJavaScript();
            }
        }
        
        // Escape - Close autocomplete or shortcuts help
        if (event.key === 'Escape') {
            hideAutocomplete(elements.cssAutocomplete);
            hideAutocomplete(elements.jsAutocomplete);
            if (elements.shortcutsHelp?.style.display !== 'none') {
                elements.shortcutsHelp.style.display = 'none';
            }
        }
        
        // Tab - Switch between tabs (when not in editor)
        if (event.key === 'Tab' && !event.target.matches('textarea')) {
            const tabs = ['css', 'js', 'settings'];
            const currentIndex = tabs.indexOf(state.currentTab);
            const nextIndex = event.shiftKey ? 
                (currentIndex - 1 + tabs.length) % tabs.length :
                (currentIndex + 1) % tabs.length;
            event.preventDefault();
            switchTab(tabs[nextIndex]);
        }
        
        // F1 - Show shortcuts help
        if (event.key === 'F1') {
            event.preventDefault();
            toggleShortcutsHelp();
        }
    }

    function toggleShortcutsHelp() {
        if (!elements.shortcutsHelp) return;
        
        const isVisible = elements.shortcutsHelp.style.display !== 'none';
        elements.shortcutsHelp.style.display = isVisible ? 'none' : 'block';
        
        if (!isVisible) {
            elements.shortcutsHelp.classList.add('fade-in');
            setTimeout(() => elements.shortcutsHelp.classList.remove('fade-in'), 300);
        }
    }

    // Window resize handler
    function handleWindowResize() {
        if (state.isFloating) {
            const rect = elements.container.getBoundingClientRect();
            const maxLeft = window.innerWidth - rect.width;
            const maxTop = window.innerHeight - rect.height;
            
            if (rect.left > maxLeft) {
                elements.container.style.left = `${Math.max(0, maxLeft)}px`;
            }
            if (rect.top > maxTop) {
                elements.container.style.top = `${Math.max(0, maxTop)}px`;
            }
        }
    }

    // Utility functions
    async function executeInActiveTab(func, args = []) {
        try {
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            if (!tab) throw new Error('No active tab found');

            return await chrome.scripting.executeScript({
                target: {tabId: tab.id},
                func: getInjectionFunction(func),
                args: args
            });
        } catch (error) {
            throw new Error(`Failed to execute in active tab: ${error.message}`);
        }
    }

    function getInjectionFunction(funcName) {
        const functions = {
            injectCSS: function(css) {
                const existingStyle = document.getElementById('live-css-tester-style');
                if (existingStyle) {
                    existingStyle.remove();
                }
                
                const style = document.createElement('style');
                style.id = 'live-css-tester-style';
                style.textContent = css;
                document.head.appendChild(style);
            },

            removeCSSInjection: function() {
                const existingStyle = document.getElementById('live-css-tester-style');
                if (existingStyle) {
                    existingStyle.remove();
                }
            },

            executeJavaScript: function(js) {
                const logs = [];
                const originalLog = console.log;
                const originalError = console.error;
                const originalWarn = console.warn;
                
                console.log = (...args) => {
                    logs.push({type: 'log', message: args.join(' ')});
                    originalLog.apply(console, args);
                };
                
                console.error = (...args) => {
                    logs.push({type: 'error', message: args.join(' ')});
                    originalError.apply(console, args);
                };
                
                console.warn = (...args) => {
                    logs.push({type: 'warn', message: args.join(' ')});
                    originalWarn.apply(console, args);
                };
                
                try {
                    eval(js);
                    return {logs: logs};
                } catch (error) {
                    return {error: error.message, logs: logs};
                } finally {
                    console.log = originalLog;
                    console.error = originalError;
                    console.warn = originalWarn;
                }
            }
        };

        return functions[funcName];
    }

    function updateStatus(message, type = 'info') {
        if (!elements.statusText) return;
        
        elements.statusText.textContent = message;
        elements.statusText.className = type;
        
        if (elements.lastUpdate) {
            elements.lastUpdate.textContent = new Date().toLocaleTimeString();
        }
        
        // Update connection status
        if (elements.connectionStatus) {
            elements.connectionStatus.className = `connection-indicator ${type === 'error' ? 'offline' : ''}`;
        }
        
        // Clear status after delay
        setTimeout(() => {
            if (elements.statusText.textContent === message) {
                elements.statusText.textContent = 'Ready';
                elements.statusText.className = '';
                if (elements.connectionStatus) {
                    elements.connectionStatus.className = 'connection-indicator';
                }
            }
        }, 3000);
    }

    // Performance monitoring
    function debounce(func, delay) {
        let timeoutId;
        return function (...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    function throttle(func, limit) {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    // Error handling
    window.addEventListener('error', function(event) {
        console.error('Global error:', event.error);
        updateStatus('Unexpected error occurred', 'error');
    });

    window.addEventListener('unhandledrejection', function(event) {
        console.error('Unhandled promise rejection:', event.reason);
        updateStatus('Promise rejection occurred', 'error');
    });

    // Cleanup
    window.addEventListener('beforeunload', function() {
        saveSettings();
        
        // Clean up event listeners
        document.removeEventListener('mousemove', handleDragging);
        document.removeEventListener('mouseup', stopDragging);
        document.removeEventListener('keydown', handleKeyboardShortcuts);
    });

    // Performance optimization: Lazy load non-critical features
    function initLazyFeatures() {
        // Initialize syntax highlighting if enabled
        if (state.settings.syntaxHighlight) {
            // Placeholder for syntax highlighting initialization
            console.log('Syntax highlighting would be initialized here');
        }

        // Initialize additional autocomplete data
        setTimeout(() => {
            loadAdditionalCSSData();
        }, 1000);
    }

    function loadAdditionalCSSData() {
        // Load more comprehensive CSS property values
        const additionalValues = {
            'animation-timing-function': ['ease', 'ease-in', 'ease-out', 'ease-in-out', 'linear'],
            'background-size': ['auto', 'cover', 'contain'],
            'border-style': ['none', 'solid', 'dashed', 'dotted', 'double'],
            'box-sizing': ['content-box', 'border-box'],
            'float': ['left', 'right', 'none'],
            'font-style': ['normal', 'italic', 'oblique'],
            'list-style-type': ['none', 'disc', 'circle', 'square', 'decimal'],
            'text-decoration': ['none', 'underline', 'overline', 'line-through'],
            'text-transform': ['none', 'uppercase', 'lowercase', 'capitalize'],
            'white-space': ['normal', 'nowrap', 'pre', 'pre-wrap', 'pre-line']
        };

        Object.entries(additionalValues).forEach(([property, values]) => {
            cssValues.set(property, [...(cssValues.get(property) || []), ...values]);
        });
    }

    // Initialize lazy features after main initialization
    setTimeout(initLazyFeatures, 100);

    // Export for debugging (only in development)
    if (chrome.runtime.getManifest().version.includes('dev')) {
        window.liveCssTester = {
            state,
            elements,
            applyCss,
            runJavaScript,
            saveSettings,
            loadSettings
        };
    }

})();