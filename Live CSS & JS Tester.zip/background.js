// Enhanced Background Script for Live CSS & JS Tester Extension
// Service Worker for Manifest V3

'use strict';

// Configuration constants
const CONFIG = {
  autoApplyDelay: 1500, // Delay before auto-applying pinned code
  badgeUpdateThrottle: 500, // Throttle badge updates
  maxRetryAttempts: 3,
  retryDelay: 1000,
  keepAliveInterval: 20000, // 20 seconds
  cacheExpiration: 300000 // 5 minutes
};

// State management for service worker
const state = {
  lastBadgeUpdate: new Map(), // Tab ID -> timestamp
  tabSettings: new Map(), // Cache tab settings
  isInitialized: false,
  keepAliveTimer: null,
  processingTabs: new Set() // Track tabs being processed
};

// Initialize extension on install/startup
chrome.runtime.onStartup.addListener(initializeExtension);
chrome.runtime.onInstalled.addListener(handleInstallation);

// Tab event listeners
chrome.tabs.onUpdated.addListener(handleTabUpdate);
chrome.tabs.onActivated.addListener(handleTabActivation);
chrome.tabs.onRemoved.addListener(handleTabRemoval);

// Storage change listener
chrome.storage.onChanged.addListener(handleStorageChange);

// Context menu click handler
chrome.contextMenus.onClicked.addListener(handleContextMenuClick);

// Message handler
chrome.runtime.onMessage.addListener(handleMessage);

// Initialize extension
async function initializeExtension() {
  try {
    console.log('Live CSS Tester: Initializing background script...');
    
    await setupContextMenus();
    await updateAllBadges();
    startKeepAlive();
    
    state.isInitialized = true;
    console.log('Live CSS Tester: Background script initialized successfully');
  } catch (error) {
    console.error('Live CSS Tester: Initialization error:', error);
  }
}

// Handle extension installation
async function handleInstallation(details) {
  console.log('Live CSS Tester: Extension event:', details.reason);
  
  try {
    if (details.reason === 'install') {
      await setDefaultSettings();
      console.log('Live CSS Tester: Default settings configured');
    } else if (details.reason === 'update') {
      await handleExtensionUpdate(details);
    }
    
    await initializeExtension();
  } catch (error) {
    console.error('Live CSS Tester: Installation error:', error);
  }
}

// Set default extension settings
async function setDefaultSettings() {
  const defaultSettings = {
    version: chrome.runtime.getManifest().version,
    installDate: new Date().toISOString(),
    autoApplyEnabled: true,
    globalSettings: {
      theme: 'auto',
      fontSize: 13,
      autoApplyDelay: true,
      syntaxHighlight: true
    }
  };
  
  await chrome.storage.local.set({ extensionSettings: defaultSettings });
}

// Handle extension updates
async function handleExtensionUpdate(details) {
  console.log(`Live CSS Tester: Updated from ${details.previousVersion}`);
  
  // Perform any migration logic here if needed
  const settings = await chrome.storage.local.get('extensionSettings');
  if (settings.extensionSettings) {
    settings.extensionSettings.version = chrome.runtime.getManifest().version;
    settings.extensionSettings.updateDate = new Date().toISOString();
    await chrome.storage.local.set({ extensionSettings: settings.extensionSettings });
  }
}

// Setup context menus
async function setupContextMenus() {
  try {
    // Remove existing menus first
    await chrome.contextMenus.removeAll();
    
    // Create main context menu
    chrome.contextMenus.create({
      id: 'openExtension',
      title: 'Open Live CSS & JS Tester',
      contexts: ['page', 'selection', 'link'],
      documentUrlPatterns: ['http://*/*', 'https://*/*']
    });
    
    // Create separator and additional options
    chrome.contextMenus.create({
      id: 'separator1',
      type: 'separator',
      contexts: ['page']
    });
    
    chrome.contextMenus.create({
      id: 'toggleAutoApply',
      title: 'Toggle Auto-Apply',
      contexts: ['page'],
      type: 'checkbox',
      checked: true
    });
    
  } catch (error) {
    console.error('Live CSS Tester: Context menu setup error:', error);
  }
}

// Handle tab updates with improved logic
async function handleTabUpdate(tabId, changeInfo, tab) {
  // Only process complete page loads on valid URLs
  if (changeInfo.status !== 'complete' || !tab.url || isSpecialPage(tab.url)) {
    return;
  }
  
  // Prevent duplicate processing
  if (state.processingTabs.has(tabId)) {
    return;
  }
  
  state.processingTabs.add(tabId);
  
  try {
    await processTabUpdate(tabId, tab);
  } catch (error) {
    console.error(`Live CSS Tester: Error processing tab ${tabId}:`, error);
  } finally {
    state.processingTabs.delete(tabId);
  }
}

// Process individual tab update
async function processTabUpdate(tabId, tab) {
  try {
    const settings = await getTabSettings(tab.url);
    
    if (settings && hasAutoApplyCode(settings)) {
      // Delay auto-apply to ensure page is fully loaded
      setTimeout(async () => {
        try {
          await autoApplyPinnedCode(tabId, settings);
          console.log(`Live CSS Tester: Auto-applied code for tab ${tabId}`);
        } catch (error) {
          console.error(`Live CSS Tester: Auto-apply error for tab ${tabId}:`, error);
        }
      }, CONFIG.autoApplyDelay);
    }
    
    // Update badge
    await updateTabBadge(tabId, tab, settings);
    
  } catch (error) {
    console.error('Live CSS Tester: Tab processing error:', error);
  }
}

// Handle tab activation
async function handleTabActivation(activeInfo) {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && !isSpecialPage(tab.url)) {
      const settings = await getTabSettings(tab.url);
      await updateTabBadge(activeInfo.tabId, tab, settings);
    }
  } catch (error) {
    console.error('Live CSS Tester: Tab activation error:', error);
  }
}

// Handle tab removal
function handleTabRemoval(tabId, removeInfo) {
  // Clean up cached data for removed tab
  state.lastBadgeUpdate.delete(tabId);
  state.tabSettings.delete(tabId);
  state.processingTabs.delete(tabId);
}

// Handle storage changes
async function handleStorageChange(changes, area) {
  if (area !== 'local') return;
  
  try {
    // Check if any settings changed that affect badges
    const settingsChanged = Object.keys(changes).some(key => key.startsWith('settings_'));
    
    if (settingsChanged) {
      // Clear settings cache
      state.tabSettings.clear();
      
      // Update all badges with throttling
      await throttledBadgeUpdate();
    }
  } catch (error) {
    console.error('Live CSS Tester: Storage change handling error:', error);
  }
}

// Throttled badge update
async function throttledBadgeUpdate() {
  const now = Date.now();
  const shouldUpdate = Array.from(state.lastBadgeUpdate.values()).every(
    timestamp => now - timestamp > CONFIG.badgeUpdateThrottle
  );
  
  if (shouldUpdate) {
    await updateAllBadges();
  }
}

// Handle context menu clicks
async function handleContextMenuClick(info, tab) {
  try {
    switch (info.menuItemId) {
      case 'openExtension':
        await chrome.action.openPopup();
        break;
        
      case 'toggleAutoApply':
        await toggleAutoApply(info.checked);
        break;
    }
  } catch (error) {
    console.error('Live CSS Tester: Context menu error:', error);
  }
}

// Toggle auto-apply setting
async function toggleAutoApply(enabled) {
  try {
    const settings = await chrome.storage.local.get('extensionSettings');
    if (settings.extensionSettings) {
      settings.extensionSettings.autoApplyEnabled = enabled;
      await chrome.storage.local.set({ extensionSettings: settings.extensionSettings });
    }
  } catch (error) {
    console.error('Live CSS Tester: Toggle auto-apply error:', error);
  }
}

// Enhanced message handler
function handleMessage(request, sender, sendResponse) {
  // Handle messages asynchronously
  (async function() {
    try {
      const response = await processMessage(request, sender);
      sendResponse(response);
    } catch (error) {
      console.error('Live CSS Tester: Message handling error:', error);
      sendResponse({ 
        success: false, 
        error: error.message,
        timestamp: Date.now()
      });
    }
  })();
  
  return true; // Keep message channel open
}

// Process individual messages
async function processMessage(request, sender) {
  switch (request.action) {
    case 'updateBadge':
      if (sender.tab) {
        const settings = await getTabSettings(sender.tab.url);
        await updateTabBadge(sender.tab.id, sender.tab, settings);
      }
      return { success: true, message: 'Badge updated' };
      
    case 'getExtensionInfo':
      return {
        version: chrome.runtime.getManifest().version,
        name: chrome.runtime.getManifest().name,
        isInitialized: state.isInitialized
      };
      
    case 'clearAllData':
      await chrome.storage.local.clear();
      state.tabSettings.clear();
      await updateAllBadges();
      return { success: true, message: 'All data cleared' };
      
    case 'getTabSettings':
      const settings = sender.tab ? await getTabSettings(sender.tab.url) : null;
      return { success: true, settings };
      
    case 'refreshBadges':
      await updateAllBadges();
      return { success: true, message: 'All badges refreshed' };
      
    default:
      throw new Error(`Unknown action: ${request.action}`);
  }
}

// Get settings for a specific URL with caching
async function getTabSettings(url, useCache = true) {
  try {
    const hostname = new URL(url).hostname;
    const cacheKey = `settings_${hostname}`;
    
    // Check cache first
    if (useCache && state.tabSettings.has(cacheKey)) {
      const cached = state.tabSettings.get(cacheKey);
      if (Date.now() - cached.timestamp < CONFIG.cacheExpiration) {
        return cached.settings;
      }
    }
    
    // Fetch from storage
    const result = await chrome.storage.local.get(cacheKey);
    const settings = result[cacheKey] || null;
    
    // Cache the result
    state.tabSettings.set(cacheKey, {
      settings,
      timestamp: Date.now()
    });
    
    return settings;
  } catch (error) {
    console.error('Live CSS Tester: Error getting tab settings:', error);
    return null;
  }
}

// Check if settings have auto-apply code
function hasAutoApplyCode(settings) {
  if (!settings) return false;
  
  const hasPinnedCSS = settings.css?.pinned && settings.css?.code && settings.css?.enabled !== false;
  const hasPinnedJS = settings.js?.pinned && settings.js?.code && settings.js?.enabled !== false;
  
  return hasPinnedCSS || hasPinnedJS;
}

// Auto-apply pinned code with enhanced error handling
async function autoApplyPinnedCode(tabId, settings, retryCount = 0) {
  try {
    // Check if auto-apply is globally enabled
    const extensionSettings = await chrome.storage.local.get('extensionSettings');
    if (extensionSettings.extensionSettings?.autoApplyEnabled === false) {
      return;
    }
    
    const results = [];
    
    // Apply pinned CSS
    if (settings.css?.pinned && settings.css?.code && settings.css?.enabled !== false) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: injectCSSFunction,
          args: [settings.css.code]
        });
        results.push({ type: 'css', success: true });
      } catch (error) {
        console.error('Live CSS Tester: CSS auto-apply error:', error);
        results.push({ type: 'css', success: false, error: error.message });
      }
    }
    
    // Apply pinned JavaScript
    if (settings.js?.pinned && settings.js?.code && settings.js?.enabled !== false) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: executeJSFunction,
          args: [settings.js.code]
        });
        results.push({ type: 'js', success: true });
      } catch (error) {
        console.error('Live CSS Tester: JS auto-apply error:', error);
        results.push({ type: 'js', success: false, error: error.message });
      }
    }
    
    return results;
    
  } catch (error) {
    console.error('Live CSS Tester: Auto-apply error:', error);
    
    // Retry logic
    if (retryCount < CONFIG.maxRetryAttempts) {
      setTimeout(() => {
        autoApplyPinnedCode(tabId, settings, retryCount + 1);
      }, CONFIG.retryDelay * (retryCount + 1));
    }
    
    throw error;
  }
}

// Update badge for specific tab
async function updateTabBadge(tabId, tab, settings = null) {
  try {
    // Throttle badge updates per tab
    const now = Date.now();
    const lastUpdate = state.lastBadgeUpdate.get(tabId) || 0;
    
    if (now - lastUpdate < CONFIG.badgeUpdateThrottle) {
      return; // Skip if updated recently
    }
    
    if (!settings) {
      settings = await getTabSettings(tab.url);
    }
    
    let badgeText = '';
    let badgeColor = '#4CAF50'; // Default green
    
    if (settings) {
      const cssPinned = settings.css?.pinned && settings.css?.code;
      const jsPinned = settings.js?.pinned && settings.js?.code;
      const cssHasCode = settings.css?.code;
      const jsHasCode = settings.js?.code;
      
      if (cssPinned && jsPinned) {
        badgeText = 'C+J';
        badgeColor = '#2196F3'; // Blue for both
      } else if (cssPinned) {
        badgeText = 'CSS';
        badgeColor = '#4CAF50'; // Green for CSS
      } else if (jsPinned) {
        badgeText = 'JS';
        badgeColor = '#FF9800'; // Orange for JS
      } else if (cssHasCode || jsHasCode) {
        badgeText = '•';
        badgeColor = '#9E9E9E'; // Gray for inactive code
      }
    }
    
    await Promise.all([
      chrome.action.setBadgeText({ text: badgeText, tabId: tabId }),
      chrome.action.setBadgeBackgroundColor({ color: badgeColor, tabId: tabId })
    ]);
    
    state.lastBadgeUpdate.set(tabId, now);
    
  } catch (error) {
    console.error(`Live CSS Tester: Badge update error for tab ${tabId}:`, error);
  }
}

// Update all tab badges
async function updateAllBadges() {
  try {
    const tabs = await chrome.tabs.query({});
    const updatePromises = tabs
      .filter(tab => tab.url && !isSpecialPage(tab.url))
      .map(tab => updateTabBadge(tab.id, tab));
    
    await Promise.allSettled(updatePromises);
    console.log(`Live CSS Tester: Updated badges for ${updatePromises.length} tabs`);
  } catch (error) {
    console.error('Live CSS Tester: Error updating all badges:', error);
  }
}

// Check if URL is a special page that can't be scripted
function isSpecialPage(url) {
  const specialPatterns = [
    /^chrome:\/\//,
    /^chrome-extension:\/\//,
    /^moz-extension:\/\//,
    /^edge-extension:\/\//,
    /^about:/,
    /^data:/,
    /^file:\/\//
  ];
  
  return specialPatterns.some(pattern => pattern.test(url));
}

// Injection function for CSS (executed in page context)
function injectCSSFunction(css) {
  try {
    const styleId = 'live-css-tester-style';
    
    // Remove existing style
    const existingStyle = document.getElementById(styleId);
    if (existingStyle) {
      existingStyle.remove();
    }
    
    // Create and inject new style
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    style.setAttribute('data-injected-by', 'live-css-tester');
    
    const target = document.head || document.documentElement;
    target.appendChild(style);
    
    return { success: true, timestamp: Date.now() };
  } catch (error) {
    console.error('Live CSS Tester: CSS injection error in page context:', error);
    throw error;
  }
}

// Injection function for JavaScript (executed in page context)
function executeJSFunction(js) {
  try {
    // Wrap execution in error handling
    const wrappedJS = `
      (function() {
        try {
          ${js}
        } catch (error) {
          console.error('Live CSS Tester JS Error:', error);
        }
      })();
    `;
    
    // Execute the code
    const script = document.createElement('script');
    script.textContent = wrappedJS;
    script.setAttribute('data-injected-by', 'live-css-tester');
    
    const target = document.head || document.body || document.documentElement;
    target.appendChild(script);
    
    // Clean up
    setTimeout(() => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    }, 100);
    
    return { success: true, timestamp: Date.now() };
  } catch (error) {
    console.error('Live CSS Tester: JS execution error in page context:', error);
    throw error;
  }
}

// Keep service worker alive
function startKeepAlive() {
  if (state.keepAliveTimer) {
    clearInterval(state.keepAliveTimer);
  }
  
  state.keepAliveTimer = setInterval(() => {
    chrome.runtime.getPlatformInfo((info) => {
      // Just a simple operation to keep the service worker alive
      console.debug('Live CSS Tester: Keep-alive ping -', new Date().toISOString());
    });
  }, CONFIG.keepAliveInterval);
}

// Handle service worker suspension
chrome.runtime.onSuspend.addListener(() => {
  console.log('Live CSS Tester: Service worker suspending, cleaning up...');
  if (state.keepAliveTimer) {
    clearInterval(state.keepAliveTimer);
    state.keepAliveTimer = null;
  }
});

console.log('Live CSS Tester: Background service worker loaded');